import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:Photo-App-Project-Flutter-main/lib/main.dart';

void main() {
  testWidgets('PhotoApp widget test', (WidgetTester tester) async {
    await tester.pumpWidget(const PhotoApp()); // Changed from MyApp to PhotoApp
    expect(find.text('Photo Gallery'), findsOneWidget);
  });
}
