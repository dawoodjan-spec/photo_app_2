import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return android;
    }
    throw UnsupportedError('DefaultFirebaseOptions are not supported for this platform.');
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCjSRTbNbcRyixJSPlNGCmxSYA84awUIBM',  // From google-services.json
    appId: '1:521676409380:android:af83d35491db63c80aa6b1',
    messagingSenderId: '521676409380',
    projectId: 'project-8770f',
    storageBucket: 'project-8770f.appspot.com',  // Corrected from .firebasestorage.app
  );
}