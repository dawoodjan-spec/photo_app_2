import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';

class DetailsScreen extends StatefulWidget { // Renamed from DetailScreen
  final String url;

  const DetailsScreen({super.key, required this.url});

  @override
  _DetailsScreenState createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  double _progress = 0.0;

  Future<void> _downloadImage() async {
    // Request storage permissions
    var status = await Permission.storage.request();
    if (!status.isGranted) {
      status = await Permission.photos.request(); // Fallback for Android 13+
      if (!status.isGranted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Storage permission denied')),
        );
        return;
      }
    }

    try {
      setState(() {
        _progress = 0.1; // Start progress
      });

      final response = await http.get(Uri.parse(widget.url));
      final Uint8List bytes = response.bodyBytes;

      final result = await PhotoManager.editor.saveImage(
        bytes,
        title: 'downloaded_image_${DateTime.now().millisecondsSinceEpoch}.jpg', filename: '',
      );

      if (result != null) {
        setState(() {
          _progress = 1.0; // Complete progress
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Image downloaded successfully')),
        );
      } else {
        throw Exception('Failed to save image');
      }
    } catch (e) {
      setState(() {
        _progress = 0.0; // Reset on error
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to download image: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.of(context).pop(),
              child: Center(
                child: Image.network(widget.url, fit: BoxFit.contain),
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              LinearProgressIndicator(
                value: _progress,
                backgroundColor: Colors.lightBlue,
                valueColor: const AlwaysStoppedAnimation(Colors.red),
              ),
              IconButton(
                iconSize: 42,
                color: Colors.lightBlue,
                icon: const Icon(Icons.file_download),
                onPressed: _downloadImage,
              ),
            ],
          ),
        ],
      ),
    );
  }
}